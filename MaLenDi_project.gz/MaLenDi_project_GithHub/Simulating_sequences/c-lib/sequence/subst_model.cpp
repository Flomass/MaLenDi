
#include "subst_model.h"

//int complement(int c)
//{
//    return 5-c;
//}



//process process::reverse_complement() const
//{
//    process p(complement(from_),complement(to_));
//    if (has_neighbor_dependency()){
//        p.set_neighbor_dependency(complement(from1_), -at1_);
//    }
//    p.set_rate(rate_);
//    return p;
//}

string process::info() const
{
    stringstream out;
    out << from_;
    if (has_neighbor_dependency()){
        out<< "(" << from1_ <<","<<at1_<<")";
    }

    out << " -> "<<to_;
    out << " "<<rate_;
    return out.str();
}



bool process::is_same_process_as(const process &p)
{
    if ((from_!=p.from_) || (to_!=p.to_) || (has_neighbor_dependency() != p.has_neighbor_dependency()))
        return false;
    
    if (has_neighbor_dependency()){
        if ((from1_!=p.from1_) || (at1_ != p.at1_))
            return false;
    }
    
    return true;
}


void substitution_model::add_process(char from, char to,int parameter_idx)
{
    add_process(from, to,0,'x', parameter_idx);
}

void substitution_model::add_process(char from,char to,int at,char from1,int parameter_idx)
{
    int from1int=0;
    if (at!=0)
        from1int=alphabet.char_to_int(from1);
    
    process_.push_back(process(alphabet.char_to_int(from),alphabet.char_to_int(to),at,from1int));
    size_t pi=process_.size()-1;
    if (parameter_.size()<parameter_idx+1){
        parameter_.resize(parameter_idx+1,parameter(1e-8,10,(parameter_idx+1)*0.01));
        parameter_to_process_map.resize(parameter_idx+1);
    }
    parameter_to_process_map[parameter_idx].push_back(pi);
}



substitution_model::substitution_model(string type)
:alphabet(DNA)
{
    type_=type;
    dt=1;
    
    if (type_=="JC"){
        add_process('A','C',0);
        add_process('T','G',0);
        add_process('A','T',0);
        add_process('T','A',0);
        add_process('C','G',0);
        add_process('G','C',0);
        add_process('C','A',0);
        add_process('G','T',0);
        
        add_process('A','G',0);
        add_process('T','C',0);
        add_process('G','A',0);
        add_process('C','T',0);
    }else if (type_=="K2P"){
        add_process('A','C',0);
        add_process('T','G',0);
        add_process('A','T',0);
        add_process('T','A',0);
        add_process('C','G',0);
        add_process('G','C',0);
        add_process('C','A',0);
        add_process('G','T',0);
        
        add_process('A','G',1);
        add_process('T','C',1);
        add_process('G','A',1);
        add_process('C','T',1);
    }else if (type_=="G6"){
        add_process('A','C',0);
        add_process('T','G',0);
        add_process('A','T',1);
        add_process('T','A',1);
        add_process('C','G',2);
        add_process('G','C',2);
        add_process('C','A',3);
        add_process('G','T',3);
        
        add_process('A','G',4);
        add_process('T','C',4);
        add_process('G','A',5);
        add_process('C','T',5);
    }else if (type_=="G12"){
        add_process('A','C',0);
        add_process('T','G',1);
        add_process('A','T',2);
        add_process('T','A',3);
        add_process('C','G',4);
        add_process('G','C',5);
        add_process('C','A',6);
        add_process('G','T',7);
        
        add_process('A','G',8);
        add_process('T','C',9);
        add_process('G','A',10);
        add_process('C','T',11);
    }else if (type_=="G12+CpG"){
        add_process('A','C',0);
        add_process('T','G',1);
        add_process('A','T',2);
        add_process('T','A',3);
        add_process('C','G',4);
        add_process('G','C',5);
        add_process('C','A',6);
        add_process('G','T',7);
        
        add_process('A','G',8);
        add_process('T','C',9);
        add_process('G','A',10);
        add_process('C','T',11);
        
        add_process('C','T',1,'G',12);
        add_process('G','A',-1,'C',13);
    }else{
        throw("undefinded model");
    }
    
    update();
    
}

void substitution_model::update()
{
    for (int i=0;i<parameter_.size();i++){
        double rate=parameter_[i].value();
        for (auto &pro : parameter_to_process_map[i]){
            process_[pro].set_rate(rate);
        }
    }
    
    
    
    
    cout << "updated subst model"<<endl;
}

string substitution_model::info() const
{
    stringstream out;
    out << type_<<endl;;
    out << number_of_parameters() << " parameter\n";
    for (const auto &p : process_){
        out << alphabet.int_to_char(p.from_);
        if (p.has_neighbor_dependency()){
            out<< "(" << alphabet.int_to_char(p.from1_) <<","<<p.at1_<<")";
        }
        out <<" -> "<< alphabet.int_to_char(p.to_)<< "  ";
        out << p.rate()<< "\n";
    }
    return out.str();
}

MatDoub substitution_model::get_Q(int len)
{
	long nn=alphabet.size(len);
	MatDoub QQ(int(nn),int(nn),0.0);
    
    
	for (int i=0;i<process_.size();i++){
		double r=process_[i].rate()*dt;
        
        if (!process_[i].has_neighbor_dependency()){
            int pl=1;
			long pL=alphabet.size(pl);
            
			int wgl=len-pl;
            
			int pii=process_[i].to_;
			int pjj=process_[i].from_;
			
            for (int k=0;k<=wgl;k++){
                long lL=alphabet.size(k);
                long rL=alphabet.size(wgl-k);
                
                for(int lk=0;lk<lL;lk++){
                    for(int rk=0;rk<rL;rk++){
                        long ii=((lk*pL)+pii)*rL+rk;
                        long jj=((lk*pL)+pjj)*rL+rk;
                        
                        QQ[int(ii)][int(jj)]+=r;
                        QQ[int(jj)][int(jj)]-=r;
                    }
                }
            }
        }
    }
	for (int i=0;i<process_.size();i++){
		double r=process_[i].rate()*dt;
        
        if (process_[i].has_neighbor_dependency()){
            int pl=1;
			long pL=alphabet.size(pl);
            
			int wgl=len-pl;
            
			int pii=process_[i].to_;
			int pjj=process_[i].from_;
			
			for (int k=0;k<=wgl;k++){
                int neighbor_pos=k+process_[i].at1_;
                if ((neighbor_pos>=0) && (neighbor_pos<len)){
                    
                
                    long cL=alphabet.size(len-1-neighbor_pos);
                    long lL=alphabet.size(k);
                    long rL=alphabet.size(wgl-k);
                    
                    for(int lk=0;lk<lL;lk++){
                        for(int rk=0;rk<rL;rk++){
                            long ii=((lk*pL)+pii)*rL+rk;
                            long jj=((lk*pL)+pjj)*rL+rk;
                            
                            if (int(jj/cL) % pL == process_[i].from1_){
                                QQ[int(ii)][int(jj)]+=r;
                                QQ[int(jj)][int(jj)]-=r;
                            }
                        }
                    }
                }
			}
        }
    }
    
	return QQ;
}


MatDoub substitution_model::get_P(int len,double t)
{
    Q=get_Q(len);
    NRmatrix_scale(Q,t);
    NRmatrix_exponential(Q,P);
    return P;
}
