#ifndef sequence_string__h
#define sequence_string__h

#include "common.h"
#include "alphabet.h"


using namespace std;



class sequence : public string
{
	private:
		string id_;

	public:
		sequence()
			:string(),id_(){}
		sequence(const string &s)
			:string(s),id_(){}

		string id()
			{return id_;}
		void set_id(const string &s)
			{id_=s;}

		string info();

        void random_sample(long len=-1);
        void shuffle();
};

long hamming_distance(const sequence &s1,const sequence &s2);


class fasta_ifstream : public ifstream
{
public:
    alphabet_index alphabet;
    
    fasta_ifstream(string filename)
    : ifstream(filename.c_str()),alphabet("acgtnACGTN-")
    {}
};

fasta_ifstream& operator>>(fasta_ifstream& in,sequence& seq);  // read from from fasta file stream


#endif


