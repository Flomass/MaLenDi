#ifndef alphabet__h
#define alphabet__h

#include <string>

#define DNA "ACGT"
#define AtoZ "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

using namespace std;


class alphabet_index
{
	private:
		char    *chars_;
		int     *ints_;
        long    *sizes_;

		size_t  size_;

		void init_NN();

	public:
		
		alphabet_index();
		alphabet_index(const char *alphabet);
		alphabet_index(size_t size);
		~alphabet_index();

		alphabet_index(const alphabet_index&);
		alphabet_index& operator=(const alphabet_index&);

		alphabet_index(alphabet_index&&);
		alphabet_index& operator=(alphabet_index&&);
		

		inline int 		char_to_int(char c) const
			{return ints_[(int) c];}
		inline char 	int_to_char(int i) const
			{return chars_[i];}
		inline string 	int_to_string(long i,size_t len) const
			{
				string s(len,' ');
				for (unsigned int k=1;k<=len;k++){
					s[len-k]=int_to_char(int(i % size_));
					i=i/size_;
				}
				return s;
			}
		inline long		string_to_int(string s) const
			{	
				long i=0,ii=0;
				for (unsigned int k=0;k<s.length();k++){
					i*=size_;
					ii=char_to_int(s[k]);
					if (ii<0) return -1;
					i=i+ii;
				}
				return i;
			}
		bool 		is_valid(string s) const
			{	
				for (unsigned int k=0;k<s.length();k++)
					if (char_to_int(s[k])==-1) return false;
				return true;
			}

		inline size_t		size() const
			{return size_;}
		inline long	size(int len) const
			{ return ( (len<64) ? sizes_[len] : -1) ;}

		inline long 	index(int k1,int k2) const
			{ return size_*k1+k2;}
		inline long 	index(int k1,int k2,int k3) const
			{ return (size_*k1+k2)*size_+k3;}
		inline long 	index(int k1,int k2,int k3,int k4) const
			{ return ((size_*k1+k2)*size_+k3)*size_+k4;}


};




#endif
