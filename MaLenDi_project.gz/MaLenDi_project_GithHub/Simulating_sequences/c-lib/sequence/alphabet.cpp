#include "alphabet.h"

#include <string.h>
#include <iostream>

alphabet_index::alphabet_index()
{
	size_=0;
	chars_=new char[256];
	ints_=new int[256];
	for (int k=0;k<256;k++){
		ints_[k]=-1;
        chars_[k]='?';
    }
    sizes_=new long[64];
    for (int k=0;k<64;k++){
        sizes_[k]=-1;
    }
    //printf("got memory\n");
}

alphabet_index::alphabet_index(const char *alphabet)
: alphabet_index()
{
	size_=int(strlen(alphabet));
	//std::cout << alphabet<< " - " <<size_<<"\n";

	for (unsigned int k=0;k<size_;k++)
		chars_[k]=alphabet[k];
	for (unsigned int k=0;k<size_;k++)
		ints_[(int)alphabet[k]]=k;
    
    
    sizes_[0]=1;
    sizes_[1]=size_;
    
	for (int k=2;k<64;k++){
        long n=sizes_[k-1]*size_;
        if (n>sizes_[k-1]) // no overflow
            sizes_[k]=n;
        else
            break;
	}

    
}


alphabet_index::~alphabet_index()
{
	delete[] chars_;
	delete[] ints_;
	delete[] sizes_;
}


alphabet_index::alphabet_index(const alphabet_index& ai)
: alphabet_index()
{
	size_=ai.size_;
	for (int k=0;k<256;k++){
		ints_[k]=ai.ints_[k];
        chars_[k]=ai.chars_[k];
    }
	for (int k=0;k<64;k++)
		sizes_[k]=ai.sizes_[k];
	//printf("alphabet_index copy constr\n");
}

alphabet_index& alphabet_index::operator=(const alphabet_index& ai) 
{
	if (this == &ai) return *this;
	size_=ai.size_;
	for (int k=0;k<256;k++){
		ints_[k]=ai.ints_[k];
        chars_[k]=ai.chars_[k];
    }
	for (int k=0;k<64;k++)
		sizes_[k]=ai.sizes_[k];

	//printf("alphabet_index copy assign\n");
    return *this;
}

alphabet_index::alphabet_index(alphabet_index&& ai)
{
    size_=ai.size_;
    chars_=ai.chars_;
    ints_=ai.ints_;
    sizes_=ai.sizes_;
    
	ai.size_=0;
    ai.chars_=nullptr;
    ai.ints_=nullptr;
    ai.sizes_=nullptr;

	//printf("alphabet_index move constr\n");
}

alphabet_index& alphabet_index::operator=(alphabet_index&& ai)
{			
	if (this==&ai) return *this;
    size_=ai.size_;
    chars_=ai.chars_;
    ints_=ai.ints_;
    sizes_=ai.sizes_;
    
	ai.size_=0;
    ai.chars_=nullptr;
    ai.ints_=nullptr;
    ai.sizes_=nullptr;

	//printf("alphabet_index move assign\n");
	return *this;

}

	
