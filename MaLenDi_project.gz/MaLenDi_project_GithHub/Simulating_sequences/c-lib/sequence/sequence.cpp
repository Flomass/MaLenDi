#include <algorithm>
#include "sequence.h"
#include "random.h"


string sequence::info()
{
    stringstream info;
    info << "length : "<<length()<<endl;
    info << "id     : "<<id_<<endl;
    info << "content: "<<substr(0,40)<<(length()>40 ? "...":"")<<endl;
    return info.str();
}

void sequence::random_sample(long len)
{
    map<char,unsigned long> m;
    for_each(cbegin(),cend(),[&m](char c) {m[c]++; });
    unsigned long M=length();
    
    if (len>=0)
        resize(len);
    
    Ran ran(initrand());
    
    auto si=begin();
    while (si!=end()){
        unsigned long r=ran.int64() % M;
        auto mi=m.begin();
        while ((mi!=m.end()) && (r >= mi->second)){
            r-=mi->second;
            mi++;
        }
        *si=mi->first;
        si++;
    }
}

void sequence::shuffle()
{
    map<char,unsigned long> m;
    for_each(cbegin(),cend(),[&m](char c) {m[c]++;});
    unsigned long M=length();
    
    Ran ran(initrand());
    
    auto si=begin();
    while (si!=end()){
        unsigned long r=ran.int64() % M;
        auto mi=m.begin();
        while ((mi!=m.end()) && (r>mi->second)){
            r-=mi->second;
            mi++;
        }
        *si=mi->first;
        mi->second--;
        if (mi->second==0)
            m.erase(mi);
        M--;
        si++;

    }

}



long hamming_distance(const sequence &s1,const sequence &s2)
{
    long L=min(s1.length(),s2.length());
    long mismatches_and_gaps=0;
    for (long k=0;k<L;k++)
        if (s1[k]!=s2[k])
            mismatches_and_gaps++;
    return mismatches_and_gaps;
}



fasta_ifstream& operator>>(fasta_ifstream& in,sequence& seq)
{
    seq.clear();
    seq.set_id("");
    
    while (!in.eof() && (in.get()!='>'))
    {}
    if (!in.eof()){
        string id;
        in >> id;
        if (in.eof()) return in;
                
        size_t n=0;
        ios::pos_type p0=in.tellg();
        char c;
        while (((c=in.get())!='>' ) && !in.eof()){
            if (in.alphabet.char_to_int(c)>=0)
                n++;
        }
        
        //cout <<"expecting "<< n<<endl;

        seq.clear();
        seq.reserve(n);
        
        in.clear();
        in.seekg(p0);
        while (((c=in.get())!='>' ) && !in.eof()){
            if (in.alphabet.char_to_int(c)>=0)
                seq.push_back(c);
        }
        if (!in.eof())
            in.putback(c);

                
        seq.set_id(id);
    }
    return in;
}
