#ifndef process__h
#define process__h

#include <iostream>
#include <sstream>

#include "parameterized_model.h"
#include "alphabet.h"
#include "nr3.h"
#include "matrix.h"

using namespace std;


class process
{
public:
    int    from_,to_;
    int    from1_;
    int    at1_;
    double rate_;

public:
    // constructor

    process(int from,int to)
    :from_(from),to_(to),from1_(0),at1_(0),rate_(0.01)
    {}
    process(int from,int to,int at1,int from1)
    :from_(from),to_(to),from1_(from1),at1_(at1),rate_(0.01)
    {}

    
    inline bool has_neighbor_dependency() const
    {
        return at1_ != 0;
    }
    
    inline void set_neighbor_dependency(char from,int at)
    {
        from1_=from;
        at1_=at;
    }
    
    inline double rate() const
    {
        return rate_;
    }
    
    inline void set_rate(double rate)
    {
        rate_=rate;
    }
    
    int length() const { return abs(at1_)+1; }
    
    string info() const;
    
    //process reverse_complement() const;
    
    bool is_same_process_as(const process &p);

};

class substitution_model : public parameterized_model {
   
private:
    alphabet_index alphabet;
    string type_;
    vector<process> process_;
    
    vector<vector<size_t>> parameter_to_process_map;
    void add_process(char from,char to,int parameter_idx);
    void add_process(char from,char to,int at,char from1,int parameter_idx);
    
    double dt;
    
    MatDoub Q;
    MatDoub P;
    
    
public:
    substitution_model(string type);
    string info() const;
    
    
    void update();

public:
    
    MatDoub get_Q(int len);
    MatDoub get_P(int len,double t);
  
    
    
};



#endif
