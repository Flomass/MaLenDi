//
//  parameterized_model.cpp
//  new_model
//
//  Created by Peter Arndt on 10/31/13.
//  Copyright (c) 2013 Peter Arndt. All rights reserved.
//

#include "parameterized_model.h"
