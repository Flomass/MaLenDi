#ifndef matrix__h
#define matrix__h

#include <thread>
#include <algorithm>
#include <string>


#include "common.h"
#include "nr3.h"

using namespace std;

void 	NRvector_minmax(VecDoub_I &A,double &min,double &max);

void 	NRmatrix_minmax(MatDoub_I &A,double &min,double &max);
double 	NRmatrix_sup_norm(MatDoub_I &A);

void 	NRmatrix_add_diagonal(MatDoub &A, double d);
void	NRmatrix_scale(MatDoub &A, double x);

void    NRmatrix_dgemm(bool TransA, bool TransB, 
			double alpha, MatDoub_I &A,MatDoub_I &B, double beta ,MatDoub &C);

		// C:= alpha A B +beta C

void 	NRmatrix_exponential(MatDoub_I &A, MatDoub &eA);

void	NRmatrix_nabla_exponential(MatDoub_I &A, MatDoub &deA);

void	NRmatrix_elementwise_log(MatDoub &A);

void	NRmatrix_tensor_product(MatDoub_I &A,MatDoub_I &B ,MatDoub &C);
		// C:= A (X) B

void	NRmatrix_tensor_product_transA(MatDoub_I &A,MatDoub_I &B ,MatDoub &C);
		// C:= tranpose(A) (X) B

void	NRmatrix_vec(MatDoub_I &A,VecDoub &V);
		// V=vec(A)  a vector with columns of A on top of each other
		
void	NRmatrix_devec(VecDoub_I &V, MatDoub &A,int rows,int cols);
		// builds (columnwise) a matrix from a vector

void	NRmatrix_copy(MatDoub_I &A,int ar0,int ar1,int ac0,int ac1,
			MatDoub &B,int br0,int bc0);
		// copyies a (sub)matrix A[ar0..ar1,ac0..ac1] 
		//   to the (sub)matrix B[br0..,bc0..]
		

void    NRmatrix_add(MatDoub &A,MatDoub_I &B);
		// A:= A + B 

void    NRmatrix_scaled_add(MatDoub &A,double beta,MatDoub_I &B,double lambda);
		// A:= lambda * (A + beta B)  

void	NRmatrix_identity(MatDoub &C,int n);


void    NRmatrix_dgemm_multi_threaded(bool TransA, bool TransB,
                                      double alpha, MatDoub_I &A,MatDoub_I &B, double beta ,MatDoub &C);
// WARNING: C has to initialized, i.e. no 'nan' in there
// WARNING: C has to be different from A and/or B




template <class T>
ostream& operator<<(ostream &out,const NRmatrix<T>& A)
{
	int n=A.nrows();
	int m=A.ncols();
	for (int i=0;i<n;i++){
		out << "[ ";
		for (int j=0;j<m;j++){
			out.precision(14);
			out << A[i][j];
			if (j<m-1) out<< " | ";
		}
		out<<" ]\n";
	}
	return out;
}

template <class T>
ostream& operator<<(ostream &out,const NRvector<T> &v)
{
	int n=v.size();
	out <<"[ ";
	for (int j=0;j<n;j++){
		out << v[j];
		if (j<n-1) out <<" | ";
	}
	out <<" ]";
	return out;
}

#endif
