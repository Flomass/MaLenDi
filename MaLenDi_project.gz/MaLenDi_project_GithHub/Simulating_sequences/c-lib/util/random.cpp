//#include <sys/time.h>  // has to be included first on linux
#include "random.h"
#include <chrono>

long  initrand() 
{
	static Ran r(0);
	static Bool init=false;
	if (!init) {
		init = true;
		chrono::time_point<chrono::high_resolution_clock> now;
		now=chrono::high_resolution_clock::now();
		
		unsigned long t=chrono::duration_cast<chrono::microseconds>(
                   now.time_since_epoch()).count() ;

		//cout << "seed="<<t<<endl;
		Ran tmp(t);
		r=tmp;		
	}
	return r.int64();
}

//long  initrand_old()
//{	
	//static long offset;
	//struct timeval		now;
	//gettimeofday(&now,NULL);
	//long t=now.tv_usec+now.tv_sec*1000000;
	
	//t*=1024;
	//t+=offset;
	//offset=(offset+1) % 1024;

	////tp=&t;
	////time(tp);

	////long pid=getpid();
	////t+=pid;

	//return(t);
//}

string stringrand(int len)
{
	Ran r(initrand());
	string c="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	string ret="";
	int lc=int(c.length());
	while (len>0){
		ret+=c.substr(r.int64() % lc,1);
		len--;
	}
	return ret;
}

//struct Binomialdev_variant : Ran {
//// this is a variant of the struct in the NR
//// made for calling the dev function with 
//// different values of (n,p).
	//Doub pp,p,pb,expnp,np,glnp,plog,pclog,sq;
	//Int n,swch;
	//Ullong uz,uo,unfin,diff,rltp;
	//Int pbits[5];
	//Doub cdf[64];
	//Doub logfact[1024];
	//Binomialdev_variant(Ullong i) : Ran(i) {
	//}	
	//Int dev(Int nn, Doub ppp){
		//pp=ppp;
		//n=nn;

		//Int j;
		//pb = p = (pp <= 0.5 ? pp : 1.0-pp);
		//if (n <= 64) {
			//uz=0;
			//uo=0xffffffffffffffffLL;
			//rltp = 0;
			//for (j=0;j<5;j++) pbits[j] = 1 & ((Int)(pb *= 2.));
			//pb -= floor(pb);
			//swch = 0;
		//} else if (n*p < 30.) {
			//cdf[0] = exp(n*log(1-p));
			//for (j=1;j<64;j++) cdf[j] =  cdf[j-1] + exp(gammln(n+1.)
				//-gammln(j+1.)-gammln(n-j+1.)+j*log(p)+(n-j)*log(1.-p));
			//swch = 1;
		//} else {
			//np = n*p;
			//glnp=gammln(n+1.);
			//plog=log(p);
			//pclog=log(1.-p);
			//sq=sqrt(np*(1.-p));
			//if (n < 1024) for (j=0;j<=n;j++) logfact[j] = gammln(j+1.);
			//swch = 2;
		//}

		//Int k,kl,km;
		//Doub y,u,v,u2,v2,b;
		//if (swch == 0) {
			//unfin = uo;
			//for (j=0;j<5;j++) {
				//diff = unfin & (int64()^(pbits[j]? uo : uz));
				//if (pbits[j]) rltp |= diff;
				//else rltp = rltp & ~diff;
				//unfin = unfin & ~diff;
			//}
			//k=0;
			//for (j=0;j<n;j++) {
				//if (unfin & 1) {if (doub() < pb) ++k;}
				//else {if (rltp & 1) ++k;}
				//unfin >>= 1;
				//rltp >>= 1;
			//}
		//} else if (swch == 1) {
			//y = doub();
			//kl = -1;
			//k = 64;
			//while (k-kl>1) {
				//km = (kl+k)/2;
				//if (y < cdf[km]) k = km;
				//else kl = km;
			//}
		//} else {
			//for (;;) {
				//u = 0.645*doub();
				//v = -0.63 + 1.25*doub();
				//v2 = SQR(v);
				//if (v >= 0.) {if (v2 > 6.5*u*(0.645-u)*(u+0.2)) continue;}
				//else {if (v2 > 8.4*u*(0.645-u)*(u+0.1)) continue;}
				//k = Int(floor(sq*(v/u)+np+0.5));
				//if (k < 0) continue;
				//u2 = SQR(u);
				//if (v >= 0.) {if (v2 < 12.25*u2*(0.615-u)*(0.92-u)) break;}
				//else {if (v2 < 7.84*u2*(0.615-u)*(1.2-u)) break;}
				//b = sq*exp(glnp+k*plog+(n-k)*pclog
					//- (n < 1024 ? logfact[k]+logfact[n-k]
						//: gammln(k+1.)+gammln(n-k+1.)));
				//if (u2 < b) break;
			//}
		//}
		//if (p != pp) k = n - k;
		//return k;
	//}
//};


#include "gamma.h"

Int Binomialdev_variant::dev(Int nn, Doub ppp){
		pp=ppp;
		n=nn;

		Int j;
		pb = p = (pp <= 0.5 ? pp : 1.0-pp);
		if (n <= 64) {
			uz=0;
			uo=0xffffffffffffffffLL;
			rltp = 0;
			for (j=0;j<5;j++) pbits[j] = 1 & ((Int)(pb *= 2.));
			pb -= floor(pb);
			swch = 0;
		} else if (n*p < 30.) {
			cdf[0] = exp(n*log(1-p));
			for (j=1;j<64;j++) cdf[j] =  cdf[j-1] + exp(gammln(n+1.)
				-gammln(j+1.)-gammln(n-j+1.)+j*log(p)+(n-j)*log(1.-p));
			swch = 1;
		} else {
			np = n*p;
			glnp=gammln(n+1.);
			plog=log(p);
			pclog=log(1.-p);
			sq=sqrt(np*(1.-p));
			if (n < 1024) for (j=0;j<=n;j++) logfact[j] = gammln(j+1.);
			swch = 2;
		}

		Int k,kl,km;
		Doub y,u,v,u2,v2,b;
		if (swch == 0) {
			unfin = uo;
			for (j=0;j<5;j++) {
				diff = unfin & (int64()^(pbits[j]? uo : uz));
				if (pbits[j]) rltp |= diff;
				else rltp = rltp & ~diff;
				unfin = unfin & ~diff;
			}
			k=0;
			for (j=0;j<n;j++) {
				if (unfin & 1) {if (doub() < pb) ++k;}
				else {if (rltp & 1) ++k;}
				unfin >>= 1;
				rltp >>= 1;
			}
		} else if (swch == 1) {
			y = doub();
			kl = -1;
			k = 64;
			while (k-kl>1) {
				km = (kl+k)/2;
				if (y < cdf[km]) k = km;
				else kl = km;
			}
		} else {
			for (;;) {
				u = 0.645*doub();
				v = -0.63 + 1.25*doub();
				v2 = SQR(v);
				if (v >= 0.) {if (v2 > 6.5*u*(0.645-u)*(u+0.2)) continue;}
				else {if (v2 > 8.4*u*(0.645-u)*(u+0.1)) continue;}
				k = Int(floor(sq*(v/u)+np+0.5));
				if (k < 0) continue;
				u2 = SQR(u);
				if (v >= 0.) {if (v2 < 12.25*u2*(0.615-u)*(0.92-u)) break;}
				else {if (v2 < 7.84*u2*(0.615-u)*(1.2-u)) break;}
				b = sq*exp(glnp+k*plog+(n-k)*pclog
					- (n < 1024 ? logfact[k]+logfact[n-k]
						: gammln(k+1.)+gammln(n-k+1.)));
				if (u2 < b) break;
			}
		}
		if (p != pp) k = n - k;
		return k;
}


/* The multinomial distribution has the form

                                      N!           n_1  n_2      n_K
   prob(n_1, n_2, ... n_K) = -------------------- p_1  p_2  ... p_K
                             (n_1! n_2! ... n_K!) 

   where n_1, n_2, ... n_K are nonnegative integers, sum_{k=1,K} n_k = N,
   and p = (p_1, p_2, ..., p_K) is a probability distribution. 

   Random variates are generated using the conditional binomial method.
   This scales well with N and does not require a setup step.

   Ref: 
   C.S. David, The computer generation of multinomial random variates,
   Comp. Stat. Data Anal. 16 (1993) 205-217
*/


vector<long> multinomialrand(long N,vector<double> p)
{
	Binomialdev_variant binomialrand(initrand());
	double norm=0;
	double sum_p=0;
	long sum_n=0;
	vector<long> n(p.size());

	for (unsigned long i=0;i<p.size();i++)
		norm+=p[i];

	for (unsigned long i=0;i<p.size();i++){
		if (p[i]>0)
			n[i]=binomialrand.dev(int(N-sum_n),p[i]/(norm-sum_p));
		else
			n[i]=0;
		sum_p+=p[i];
		sum_n+=n[i];
	}
	return n;
}
	

