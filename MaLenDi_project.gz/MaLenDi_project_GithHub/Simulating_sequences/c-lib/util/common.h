#ifndef common__h
#define common__h

#include <set>
#include <map>
#include <list>
#include <vector>
#include <string>
#include <chrono>
#include <ctime>

#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>

#include <cstdlib>
#include <functional>
#include <cmath>


#include "nr3.h"

using namespace std;


//	basic start/stop procedure
//
void    StartUp (int argc=-1,const char *argv[]=NULL,
                 bool ask_if_parameter_not_on_commandline=true);
void	StopDown();


std::ostream& Debug(int level);

//	input of data  
//
void 	GetValue(string text,int &var);
void	GetValue(string text,long &var);
void 	GetValue(string text,double &var);
bool 	GetValue(string text,string &var);
void 	GetValue(string text,bool &var);

void 	set_value(string id,string val);


//	output of data (number -> string)
//
string 	toa(const double num, int pre=3);
string 	toa(const int num);
string 	toa(const long num);
string 	toa(const bool val);


void 	message(string messagestr,int message_debug_level=2);

string	system_stdout(const  string command);

#endif
