#include "progress.h"
#include "common.h"


using namespace std;

progress::progress(double max)
:max(max)
{
	next_x=0;
	last_x=0;
    seconds_between_messages_=30;

	start_time=chrono::high_resolution_clock::now();
	last_time=start_time;

	message("start");
}

progress::~progress()
{
	chrono::time_point<chrono::high_resolution_clock> now;
	now=chrono::high_resolution_clock::now();

	unsigned long sec = chrono::duration_cast<chrono::seconds>
                             (now-start_time).count();
	unsigned long min,hour;

	
	min=sec/60;
	hour=min/60;
	min=min%60;
	sec=sec-3600*hour-60*min;

	stringstream m;
	if (hour!=0)
		m << "total time: " << hour << " h  " << min << " min" <<endl;
	else
		m << "total time: " << min << " min  " << sec << " sec" <<endl;
	message(m.str());
}
	
	

void	progress::progress_message(double x)
{
	if (x==last_x) return;

	chrono::time_point<chrono::high_resolution_clock> now;
	now=chrono::high_resolution_clock::now();

	unsigned long 	sec,min,hour;
	unsigned long 	dt = chrono::duration_cast<chrono::microseconds>
                             (now-last_time).count();

	unsigned long   ticks_per_sec=1000000;

	sec=(long) (((max-x)*dt/(x-last_x))/ticks_per_sec);
	next_x=x+seconds_between_messages_*ticks_per_sec*(x-last_x)/dt;
	
	min=sec/60;
	hour=min/60;
	min=min%60;
	sec=sec-3600*hour-60*min;

	double percentage=x/max;

	Debug(2) << "# "<<toa(percentage*100,1) << "% -- ready in " ;
		
	if (hour!=0){
		Debug(2) << hour << " h  "<< min  << " min  ";
	}else if (min != 0){
		Debug(2) << min  << " min  "<< sec  << " sec";
	}else
		Debug(2) << sec  << " sec";

	Debug(2) <<"      \r" << flush;

	
	
	last_time=now;
	last_x=x;
}

