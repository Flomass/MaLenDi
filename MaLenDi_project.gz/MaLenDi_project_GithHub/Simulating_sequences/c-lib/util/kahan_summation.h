#include <set>

using namespace std;

class kahan_summation
// reduce rounding errors when summing
// see http://en.wikipedia.org/wiki/Kahan_summation_algorithm
{
	private:
		double s,c;
		double y,t;
	public:
	
	kahan_summation()
		{s=0;c=0;}
	inline void add(double a){
		y=a-c;
		t=s+y;
		c=(t-s)-y;
		s=t;
	}
	void clear()
		{s=0;c=0;}
	inline double sum()
		{return s;}	
};



struct less_fabs
{
	inline bool operator()(const double a,const double b)
	{
		return fabs(a)<fabs(b);
	}
};


class kahan_summation_by_absolute_value : private multiset<double,less_fabs>
{
	public:

	kahan_summation_by_absolute_value()
		{clear();}

	inline void add(double a)
		{insert(a);}
	void clear()
		{multiset<double,less_fabs>::clear();}
	inline double sum(){
		kahan_summation s;
		multiset<double,less_fabs>::iterator it=begin();
		while (it!=end()){
			s.add(*it);
			it++;
		}
		return s.sum();
	}	
};


class summation_by_absolute_value : private multiset<double,less_fabs>
{
	public:

	summation_by_absolute_value()
		{clear();}

	inline void add(double a)
		{insert(a);}
	void clear()
		{multiset<double,less_fabs>::clear();}
	inline double sum(){
		multiset<double,less_fabs>::iterator i1,i2;
		i1=begin();
		if (i1==end())
			return 0;
		while (1==1){
			i1=begin();
			i2=begin();
			i2++;
			if (i2==end())
				return *i1;
			double s= (*i1) + (*i2);
			erase(i1);
			erase(i2);
			insert(s);
		}
		return 0;
	}	
};


