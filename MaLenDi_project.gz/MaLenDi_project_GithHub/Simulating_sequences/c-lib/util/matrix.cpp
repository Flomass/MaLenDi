#include "matrix.h"

#include <thread>

void NRvector_minmax(VecDoub_I &A,double &min,double &max)
{
	int n=A.size();
	double h;
	if (n>0){
		min=max=A[0];
		for (int i=0;i<n;i++){
			h=A[i];
			if (h>max) max=h;
			if (h<min) min=h;
		}
	}
}

void NRmatrix_minmax(MatDoub_I &A,double &min,double &max)
{
	int n=A.nrows();
	int m=A.ncols();
	double h;
	if ((n>0) && (m>0)){
		min=max=A[0][0];
		for (int i=0;i<n;i++)
			for (int j=0;j<m;j++){
				h=A[i][j];
				if (h>max) max=h;
				if (h<min) min=h;
			}
	}
}


double NRmatrix_sup_norm(MatDoub_I &A)
{
	double min, max;
	NRmatrix_minmax(A,min,max);
	return MAX(fabs(min),fabs(max));
}

void	NRmatrix_add_diagonal(MatDoub &A, double d)
{
	int n=A.nrows();
	int m=A.ncols();
	int loop_lim = ( m < n ? m : n );
	for (int k=0;k<loop_lim;k++)
		A[k][k]+=d;
}

void	NRmatrix_scale(MatDoub &A, double x)
{
	int n=A.nrows();
	int m=A.ncols();
	for (int i=0;i<n;i++)
		for (int j=0;j<m;j++)
			A[i][j]*=x;
}


void    NRmatrix_dgemm(bool TransA, bool TransB, 
			double alpha, MatDoub_I &A,MatDoub_I &B, double beta ,MatDoub &C)
// WARNING: C has to initialized, i.e. no 'nan' in there
// WARNING: C has to be different from A and/or B
{
	if (TransA  || TransB) throw("not implemented yet");

	int nA=A.nrows();
	int mA=A.ncols();
	int nB=B.nrows();
	int mB=B.ncols();
	int nC=C.nrows();
	int mC=C.ncols();

	if ((nA !=nC) || (mA != nB) || (mB != mC)) throw("dimensions mismatch");
	
	double h;
	for(int i=0;i<nC;i++)
		for(int j=0;j<mC;j++){
			h=0;
			for(int k=0;k<mA;k++)
				h+=A[i][k]*B[k][j];
			h*=alpha;
			C[i][j]=C[i][j]*beta+h;
		}
}


void	NRmatrix_copy(MatDoub_I &A,int ar0,int ar1,int ac0,int ac1,
			MatDoub &B,int br0,int bc0)
{
	int br1=br0+ar1-ar0;
	int bc1=bc0+ac1-ac0;
	if ((ar1<ar0)||(ar0<0)||(ar1>=A.nrows())) throw("A row index wrong");	
	if ((ac1<ac0)||(ac0<0)||(ac1>=A.ncols())) throw("A col index wrong");	
	if ((br1<br0)||(br0<0)||(br1>=B.nrows())) throw("B row index wrong");	
	if ((bc1<bc0)||(bc0<0)||(bc1>=B.ncols())) throw("B col index wrong");	

	int m=br0;	
	for(int i=ar0;i<=ar1;i++){
		int n=bc0;
		for(int j=ac0;j<=ac1;j++)
			B[m][n++]=A[i][j];
		m++;
	}
}


void	NRmatrix_elementwise_log(MatDoub &A)
{
	int n=A.nrows();
	int m=A.ncols();
	for (int i=0;i<n;i++)
		for (int j=0;j<m;j++)
			A[i][j]=log(fabs(A[i][j]));
}



void	NRmatrix_vec(MatDoub_I &A,VecDoub &V)
{
	int n=A.nrows();
	int m=A.ncols();
	int k=0;
	
	V.resize(n*m);
	for (int i=0;i<n;i++)
		for (int j=0;j<m;j++)
			V[k++]=A[i][j];
}


void	NRmatrix_devec(VecDoub_I &V, MatDoub &A,int rows,int cols)
{
	A.resize(rows,cols);
	int k=0;
	for (int i=0;i<rows;i++)
		for (int j=0;j<cols;j++){
			if (k<V.size())
				A[i][j]=V[k++];
			else
				A[i][j]=0;
		}
}
		


/* Calculate the matrix exponential, following
 * Moler + Van Loan, SIAM Rev. 20, 801 (1978).
 */



/* store one of the suggested choices for the
 * Taylor series / square  method from Moler + VanLoan
 */
struct moler_vanloan_optimal_suggestion
{
  int k;
  int j;
};
typedef  struct moler_vanloan_optimal_suggestion  mvl_suggestion_t;


/* table from Moler and Van Loan
 * mvl_tab[gsl_mode_t][matrix_norm_group]
 */
static mvl_suggestion_t mvl_tab[3][6] =
{
  /* double precision */
  {
    { 5, 1 }, { 5, 4 }, { 7, 5 }, { 9, 7 }, { 10, 10 }, { 8, 14 }
  },

  /* single precision */
  {
    { 2, 1 }, { 4, 0 }, { 7, 1 }, { 6, 5 }, { 5, 9 }, { 7, 11 }
  },

  /* approx precision */
  {
    { 1, 0 }, { 3, 0 }, { 5, 1 }, { 4, 5 }, { 4, 8 }, { 2, 11 }
  }
};


static
mvl_suggestion_t
obtain_suggestion(MatDoub_I &A)
{
  const unsigned int mode_prec = 0;
  const double norm_A = NRmatrix_sup_norm(A);
  if(norm_A < 0.01) return mvl_tab[mode_prec][0];
  else if(norm_A < 0.1) return mvl_tab[mode_prec][1];
  else if(norm_A < 1.0) return mvl_tab[mode_prec][2];
  else if(norm_A < 10.0) return mvl_tab[mode_prec][3];
  else if(norm_A < 100.0) return mvl_tab[mode_prec][4];
  else if(norm_A < 1000.0) return mvl_tab[mode_prec][5];
  else
  {
    /* outside the table we simply increase the number
     * of squarings, bringing the reduced matrix into
     * the range of the table; this is obviously suboptimal,
     * but that is the price paid for not having those extra
     * table entries
     */
    const double extra = log(1.01*norm_A/1000.0) / M_LN2;
    const int extra_i = (unsigned int) ceil(extra);
    mvl_suggestion_t s = mvl_tab[mode_prec][5];
    s.j += extra_i;
    return s;
  }
}


/* use series representation to calculate matrix exponential;
 * this is used for small matrices; we use the sup_norm
 * to measure the size of the terms in the expansion
 */
static void
NRmatrix_exp_series(MatDoub &B, MatDoub &eB, int number_of_terms)
{
	int count;
	MatDoub temp(B.nrows(),B.ncols(),0.0);

  /* init the Horner polynomial evaluation,
   * eB = 1 + B/number_of_terms; we use
   * eB to collect the partial results
   */  

	eB=B;
	NRmatrix_scale(eB, 1.0/number_of_terms);
	NRmatrix_add_diagonal(eB, 1.0);

	for(count = number_of_terms-1; count >= 1; --count){
		/*  mult_temp = 1 + B eB / count  */
		NRmatrix_dgemm(false, false, 1.0, B, eB, 0.0, temp);
		NRmatrix_scale(temp, 1.0/count);
		NRmatrix_add_diagonal(temp, 1.0);

		/*  transfer partial result out of temp */
		eB=temp;
	}
	  /* now eB holds the full result; we're done */
}

//#define M_LN2      0.69314718055994530941723212146      /* ln(2) */


void 	NRmatrix_exponential(MatDoub_I &A, MatDoub &eA)
{
	if (A.nrows()!=A.ncols()) throw("cannot exponentiate a non-square matrix");

    int i;
    mvl_suggestion_t sugg = obtain_suggestion(A);
	//cout<<sugg.k<<" "<<sugg.j<<endl;
    const double divisor = exp(M_LN2 * sugg.j);

    MatDoub reduced_A = A;

    /*  decrease A by the calculated divisor  */
    NRmatrix_scale(reduced_A, 1.0/divisor);

    /*  calculate exp of reduced matrix; store in eA as temp  */
    NRmatrix_exp_series(reduced_A, eA, sugg.k);

	
    /*  square repeatedly; use reduced_A for scratch */
	for(i = 0; i < sugg.j; ++i){
    	NRmatrix_dgemm(false, false, 1.0, eA, eA, 0.0, reduced_A);
    	eA=reduced_A;
	}
}

void	NRmatrix_nabla_exponential(MatDoub_I &A, MatDoub &deA)
{
	if (A.nrows()!=A.ncols()) throw("cannot nabla exponentiate a non-square matrix");
	int n=A.nrows();
	int nn=n*n;

	MatDoub In;
	NRmatrix_identity(In,n);
	MatDoub Inn;
	NRmatrix_identity(Inn,nn);

	MatDoub C11;
	NRmatrix_tensor_product_transA(A,In,C11);
	MatDoub C22;
	NRmatrix_tensor_product(In,A,C22);

	MatDoub C;
	C.assign(2*nn,2*nn,0.0);
	NRmatrix_copy(C11,0,nn-1,0,nn-1,C,0,0);
	NRmatrix_copy(Inn,0,nn-1,0,nn-1,C,0,nn);
	NRmatrix_copy(C22,0,nn-1,0,nn-1,C,nn,nn);
	

	MatDoub eC;
	NRmatrix_exponential(C,eC);

	deA.resize(nn,nn);
	NRmatrix_copy(eC,0,nn-1,nn,2*nn-1,deA,0,0);
}




void	NRmatrix_tensor_product(MatDoub_I &A,MatDoub_I &B ,MatDoub &C)
{
	int Ccols=A.ncols()*B.ncols();
	int Crows=A.nrows()*B.nrows();
	C.resize(Crows,Ccols);

	for (int ra=0;ra<A.nrows();ra++)
		for (int rb=0;rb<B.nrows();rb++)
			for (int ca=0;ca<A.ncols();ca++)
				for (int cb=0;cb<B.ncols();cb++)
					C[ra*B.nrows()+rb][ca*B.ncols()+cb]=A[ra][ca]*B[rb][cb];
}

void	NRmatrix_tensor_product_transA(MatDoub_I &A,MatDoub_I &B ,MatDoub &C)
{
	int Ccols=A.nrows()*B.ncols();
	int Crows=A.ncols()*B.nrows();
	C.resize(Crows,Ccols);

	for (int ra=0;ra<A.ncols();ra++)
		for (int rb=0;rb<B.nrows();rb++)
			for (int ca=0;ca<A.nrows();ca++)
				for (int cb=0;cb<B.ncols();cb++)
					C[ra*B.nrows()+rb][ca*B.ncols()+cb]=A[ca][ra]*B[rb][cb];
}


void	NRmatrix_identity(MatDoub &C,int n)
{
	C.assign(n,n,0.0);
	for (int k=0;k<n;k++)
		C[k][k]=1.0;
}

void    NRmatrix_add(MatDoub &A,MatDoub_I &B)
{
	for (int ra=0;ra<A.nrows();ra++)
		for (int ca=0;ca<A.ncols();ca++)
			A[ra][ca]+=B[ra][ca];
}

void    NRmatrix_scaled_add(MatDoub &A,double beta,MatDoub_I &B,double lambda)
{
	for (int ra=0;ra<A.nrows();ra++)
		for (int ca=0;ca<A.ncols();ca++)
			A[ra][ca]=lambda*(A[ra][ca]+beta*B[ra][ca]);
}

//  MULTI threaded


void    NRmatrix_dgemm_multi_threaded_func(bool TransA, bool TransB,
                                           double alpha, MatDoub_I &A,MatDoub_I &B, double beta ,MatDoub &C,
                                           int start,int end)
{
	int mC=C.ncols();
	int mA=A.ncols();
	double h;
	for(int i=start;i<end;i++)
		for(int j=0;j<mC;j++){
			h=0;
			for(int k=0;k<mA;k++)
				h+=A[i][k]*B[k][j];
			h*=alpha;
			C[i][j]=C[i][j]*beta+h;
		}
}


void    NRmatrix_dgemm_multi_threaded(bool TransA, bool TransB,
                                      double alpha, MatDoub_I &A,MatDoub_I &B, double beta ,MatDoub &C)
// WARNING: C has to initialized, i.e. no 'nan' in there
// WARNING: C has to be different from A and/or B
{
	if (TransA  || TransB) throw("not implemented yet");
    
	int nA=A.nrows();
	int mA=A.ncols();
	int nB=B.nrows();
	int mB=B.ncols();
	int nC=C.nrows();
	int mC=C.ncols();
    
	if ((nA !=nC) || (mA != nB) || (mB != mC)) throw("dimensions mismatch");
	
    
    unsigned long const length=nC;
    
    unsigned long const min_per_thread=25;
    unsigned long const max_threads=
    (length+min_per_thread-1)/min_per_thread;
    
    unsigned long const hardware_threads=
    thread::hardware_concurrency();
    
    unsigned long const num_threads=
    min(hardware_threads!=0?hardware_threads:2,max_threads);
    
    unsigned long const block_size=length/num_threads;
    
    vector<thread>  threads(num_threads-1);
    
	int block_start=0;
    for(unsigned long k=0;k<(num_threads-1);++k)
    {
        int block_end=block_start;
		block_end+=block_size;
        cout << block_start<<" "<<block_end<<" "<<k<<endl;
        threads[k]=std::thread(
                               NRmatrix_dgemm_multi_threaded_func,TransA, TransB,
                               alpha, ref(A), ref(B), beta , ref(C),
                               block_start, block_end);
        block_start=block_end;
    }
    cout << block_start<<" "<<nC<<" "<<"me"<<endl;
	NRmatrix_dgemm_multi_threaded_func(TransA, TransB,
                                       alpha, ref(A), ref(B), beta , ref(C),
                                       block_start, nC);
    
    for_each(threads.begin(),threads.end(),
             mem_fn(&thread::join));
    
}




