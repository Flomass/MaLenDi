//
//  parameterized_model.h
//  new_model
//
//  Created by Peter Arndt on 10/31/13.
//  Copyright (c) 2013 Peter Arndt. All rights reserved.
//

#ifndef __parameterized_model__
#define __parameterized_model__

#include <iostream>
#include <vector>
#include <cmath>

using namespace std;


class parameter {
    
public:
    static constexpr double infinity=1e100;
    
private:
    double value_;
    double min_,max_;
    double eps_;
    enum { open,closed,open_left,open_right } type_;
    
public:
    parameter()
    : value_(0),type_(open),min_(-infinity),max_(infinity),eps_(1e-8)
    {}
    parameter(double val)
    : value_(val),type_(open),min_(-infinity),max_(infinity),eps_(1e-8)
    {}
    parameter(double min,double max,double val)
    : value_(val),min_(min),max_(max),eps_(1e-8)
    {
        if (min_<=-infinity){
            if (max_>infinity)
                type_=open;
            else
                type_=open_left;
        }else{
            if (max_>infinity)
                type_=open_right;
            else
                type_=closed;
        }
    }
    
    inline double value() const { return value_;}
    inline double r_value() const { return x_to_r(value());}
    
    bool set_value(double x)
    {
        bool has_changed=false;
        if (fabs(value_-x)>eps_){
            has_changed=true;
            cout << "changing value "<<value_<<" to "<<x<<endl;
        }
        value_=x;
        if (has_changed)
            update();
        return has_changed;
    }
    
    bool set_r_value(double r) { return set_value(r_to_x(r)); }
    
    virtual void update()
    {
        cout<<"update parameter"<<endl;
    }
    
private:
    double r_to_x(double r) const
    {
        double h;
        switch (type_){
            case open:
                return r;
            case closed:
                if (r<0) r=-r;
                if (r>1) r=r-(int)r;
                h=r-1;
                h=h*h*r*r*16.0;
                return min_+(max_-min_)*h;
            case open_right:
                return min_+exp(r);
            case open_left:
                return max_-exp(-r);
        }
    }
    
    double x_to_r(double x) const
    {
        double h;
        switch (type_){
            case open:
                return x;
            case closed:
                h=(x-min_)/(max_-min_);
                if (h<0) return 0;
                if (h>1) return 0.5;
                return (1-sqrt(1-sqrt(h)))/2.0;
            case open_right:
                h=x-min_;
                if (h<=0) return -infinity;
                return log(h);
            case open_left:
                h=max_-x;
                if (h<=0) return infinity;
                return -log(h);
        }
    }
    
      
};



class parameterized_model {
    
public:
    vector<parameter> parameter_;
    vector<parameterized_model*> parameterized_model_;  // this might not work properly
    
public:
    
    void add_parameter(parameter p)
    {
        parameter_.push_back(p);
    }
    
    void add_parameterized_model(parameterized_model *p)
    {
        parameterized_model_.push_back(p);
    }
    
    
    size_t number_of_parameters() const
    {
        size_t n=parameter_.size();
        for (const auto &pmi : parameterized_model_){
            n+=pmi->number_of_parameters();
        }
        return n;
    }

    // set parameter
    bool set_parameter(vector<double>::iterator &xi)
    {
        bool has_changed=false;
        
        for (auto &pi : parameter_){
            has_changed |= pi.set_value( *xi );
            xi++;
        }
        for (auto &pmi : parameterized_model_){
            has_changed |= pmi->set_parameter( xi );
        }
        
        if (has_changed)
            update();
        
        return has_changed;
    }
    
    bool set_parameter(vector<double> x)
    {
        auto xi=x.begin();
        bool has_changed=set_parameter(xi);
        return has_changed;
    }
    
    // get parameter
    void get_parameter(vector<double> &p) const
    {
        for (const auto &pi : parameter_){
            p.push_back(pi.value());
        }
        for (const auto &pmi : parameterized_model_){
            pmi->get_parameter( p );
        }
    }
    
    vector<double> get_parameter() const
    {
        vector<double> p;
        get_parameter(p);
        return p;
    }
    
    // set r-parameter
    bool set_r_parameter(vector<double>::iterator &ri)
    {
        bool has_changed=false;
        
        for (auto &pi : parameter_){
            has_changed |= pi.set_value( *ri );
            ri++;
        }
        for (auto &pmi : parameterized_model_){
            has_changed |= pmi->set_parameter( ri );
        }
        
        if (has_changed)
            update();
        
        return has_changed;
    }
    
    bool set_r_parameter(vector<double> r)
    {
        auto ri=r.begin();
        bool has_changed=set_parameter(ri);
        return has_changed;
    }
    
    // get r-parameter
    void get_r_parameter(vector<double> &p) const
    {
        for (const auto &pi : parameter_){
            p.push_back(pi.r_value());
        }
        for (const auto &pmi : parameterized_model_){
            pmi->get_r_parameter( p );
        }
    }
    
    vector<double> get_r_parameter() const
    {
        vector<double> p;
        get_r_parameter(p);
        return p;
    }
    

    // update
    virtual void update()
    {
        cout<<"update parameterized_model"<<endl;
    }

    
};


#endif