#ifndef progress__h
#define progress__h

#include <chrono>
#include <ctime>


class progress{
public:

    progress(double max=1);

    inline void stat(double x)
        { if (x>next_x) progress_message(x); }
        
    ~progress();
    
    void seconds_between_messages(int s)
        { seconds_between_messages_=s;}

private:

    void progress_message(double x);

    double max;

    std::chrono::time_point<std::chrono::high_resolution_clock> 	start_time,last_time;	

    double last_x;
    double next_x;
    int seconds_between_messages_;
};



#endif
