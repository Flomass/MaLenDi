#include "common.h"




namespace{
	
string 				executable_name="";
map<string,string> 	parameters;
bool 				ask_for_parameters_not_on_commandline=true;

time_t 				start_time,last_message_time;	

#define show_debug_level 3

// 1 startup+stopdown
// 2 messages
// 3 more

}



std::ostream& Debug(int level) 
{
	std::clog.clear(level <= show_debug_level ? std::ios_base::goodbit : std::ios_base::badbit);
	return std::clog;
}


/*-------------------------------------------------*/
/*   prints: day time message                      */
/*-------------------------------------------------*/
	
string sec_to_time(long sec)
{
    long    min,hour;
    if (sec<0) sec=0;

    min=sec/60;
    hour=min/60;
    min=min%60;
    sec=sec-3600*hour-60*min;

    string ret="";
    if (hour!=0)
        ret=toa(hour)+"h "+toa(min)+"min";
    else if (min!=0)
        ret=toa(min)+"min "+toa(sec)+"sec";
    else
        ret=toa(sec)+"sec";

    return ret;
}

string 	time_t_to_date(time_t t)
{	
	char s[80];
	struct tm *tp2;

	tp2=localtime(&t);
	strftime(s,80,"%a %d.%m.%Y %H:%M:%S",tp2);
	string ret=s;
	return  ret;
}


void 	message(string messagestr,int message_debug_level)

{
	time_t now=time(NULL);

	Debug(message_debug_level) << time_t_to_date(now) <<" " 
		<< "("<<sec_to_time(now-start_time)<<","
		<< "+"<<sec_to_time(now-last_message_time)<<")  "
		<< messagestr << endl;

	last_message_time=now;
}



namespace{


void read_from_parameters_from_argv(int argc,const char **argv)
{
	string arg,key,value;
	unsigned long pos;

	for (int i=1;i<argc;i++){
		arg=argv[i];
		pos=arg.find("=");
		if (pos!=string::npos){
			key.assign(arg,0,pos);
			value.assign(arg,pos+1,string::npos);
			set_value(key,value);
			Debug(3) << key << " -> "<<value<<endl;
		}
	}
}
				
string  get_answer_dialog(string question)
{
        string answer;
        cout << question << endl;
        getline(cin,answer);
        return answer;
}


}





//-----------------------------------------------------------------	

void    StartUp(int argc,const char *argv[],
                bool ask_for_parameters_not_on_commandline_)
{
	ask_for_parameters_not_on_commandline=ask_for_parameters_not_on_commandline_;

	start_time = time(NULL);
	last_message_time=start_time;


	message("START",1);
	Debug(3) <<"argc:"<<argc<<endl;
	for (int i=0;i<argc;i++){
		Debug(3)<<"argv["<<i<<"]:"<<argv[i]<<endl;
	}
    if (argv!=NULL)
        executable_name=argv[0];
    else
        executable_name="unknown";

	read_from_parameters_from_argv(argc,argv);
	Debug(1) << "---------------------------------------------------" << endl;


	atexit(StopDown);
}

void 	StopDown ()
{
	Debug(1) << "---------------------------------------------------" << endl;

	Debug(1) << executable_name ;
	for (auto& elem : parameters) {
		string quote=(elem.second.find_first_of("()[];,|<> ")!=string::npos ? "\"":"");
		Debug(1) << " " << elem.first << "=" << quote << elem.second << quote;
	}
	Debug(1) << endl;

	Debug(1) << "---------------------------------------------------" << endl;
	message("END",1);
}

	
//-----------------------------------------------------------------	
	

bool 	GetValue(string id,string &var)
{	
	string val;
	bool took_default_value=false;
	bool take_default_if_prog_para_is_empty=true;
	if (parameters.find(id) != parameters.end()){
		if (take_default_if_prog_para_is_empty && (parameters[id].length()==0)){
			 took_default_value=true;
		}else{
			var=parameters[id];
			 took_default_value=false;
		}
	}else{
		if(ask_for_parameters_not_on_commandline){
			string question =(string)"The value of "+id+" ["+var+"] ";
			val=get_answer_dialog(question);
			
			took_default_value=(val.length()==0);
			if (!took_default_value){
				var=val;
			}
			set_value(id,var);
		}else{
			cout << "ERROR: Did not find a value for " << id << " on the commandline"<<endl;
			exit(1);
		}
	}
	
	return took_default_value;
}

void 	GetValue(string id,int &var)
{
	string svar=toa(var);
	GetValue(id,svar);
	var=atoi(svar.c_str());
}

void 	GetValue(string id,long &var)
{
	string svar=toa(var);
	GetValue(id,svar);
	var=atol(svar.c_str());
}

void 	GetValue(string id,double &var)
{
	string svar=toa(var,5);
	bool take_default_value=GetValue(id,svar);
	if (!take_default_value)
		var=atof(svar.c_str());
}

void 	GetValue(string id,bool &var)
{
	string svar="false";
	if (var) svar="true";
	bool take_default_value=GetValue(id,svar);
	if (!take_default_value){
		if ((svar=="0") || (svar[0]=='f') || (svar[0]=='F')){
			var=false;
			set_value(id,"false");
		}else{
			var=true;
			set_value(id,"true");
		}
	}
}

void 	set_value(string id,string value)
{
	parameters[id]=value;
}


//-----------------------------------------------------------------	
string	system_stdout(const  string command)
{
	string ret="";
	int buflen=1000000;
	char *buf=new char[buflen];
	FILE *fp = popen(command.c_str(), "r" );
	while ( fgets( buf, sizeof buf, fp ) != NULL ) {
		ret+=buf;
	}
	pclose( fp );
	delete[] buf;
	return ret;
}

//-----------------------------------------------------------------	

string 	toa(const double num, int pre)
{
	ostringstream toa_ss;

	toa_ss.setf(ios::fixed,ios::floatfield);
	toa_ss.precision(pre);
	toa_ss << num;
	
	return toa_ss.str();
}

string 	toa(const int num)
{
	ostringstream toa_ss;

	toa_ss << num;
	
	return toa_ss.str();
}

string 	toa(const long num)
{
	ostringstream toa_ss;

	toa_ss << num;
	
	return toa_ss.str();
}

string 	toa(const bool val)
{
	stringstream toa_ss;

	toa_ss << val;
	
	return toa_ss.str();
}
