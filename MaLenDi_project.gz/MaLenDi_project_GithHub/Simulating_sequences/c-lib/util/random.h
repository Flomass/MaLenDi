#ifndef my_random__h
#define my_random__h

#include <string>
#include <vector>
#include "nr3.h"
#include "ran.h"

using namespace std;



long   initrand();
long   initrand2();

string	stringrand(int len=32);

vector<long> multinomialrand(long N,vector<double> p);



struct Binomialdev_variant : Ran {
// this is a variant of the struct in the NR
// made for calling the dev function with 
// different values of (n,p).
	Doub pp,p,pb,expnp,np,glnp,plog,pclog,sq;
	Int n,swch;
	Ullong uz,uo,unfin,diff,rltp;
	Int pbits[5];
	Doub cdf[64];
	Doub logfact[1024];

	Binomialdev_variant(Ullong i): Ran(i) {
	}	
	Int dev(Int nn, Doub ppp);
};


#endif

